﻿using System;
using System.Text;
using System.Collections.Generic;

namespace PriceReceive
{
    class Program
    {
        public static void Main(string[] args)
        {
            var productDict = InitProductDictionary();
            var routingKey = (args.Length > 0) ? args[0] : "1";
            var msgHndlr = new MessageHandler("localhost", routingKey, productDict);
            msgHndlr.Start();
        }

        private static Dictionary<string,Product> InitProductDictionary()
        {
            Dictionary<string, Product> retDict = new Dictionary<string, Product>();

            retDict.Add("AAA", new Product
            {
                ProductName = "AAA",
                ProductOptionPrice = 0.52F,
                DefaultCounterparty = "ABC"
            });
            retDict.Add("BBB", new Product
            {
                ProductName = "BBB",
                ProductOptionPrice = 0.355F,
                DefaultCounterparty = "DEF"
            });
            retDict.Add("CCC", new Product
            {
                ProductName = "CCC",
                ProductOptionPrice = 0.11F,
                DefaultCounterparty = "DEF"
            });
            retDict.Add("DDD", new Product
            {
                ProductName = "DDD",
                ProductOptionPrice = 0.029F,
                DefaultCounterparty = "ABC"
            });
            retDict.Add("EEE", new Product
            {
                ProductName = "EEE",
                ProductOptionPrice = 0.045F,
                DefaultCounterparty = "JJJ"
            });

            return retDict;
        }

        
    }
}

