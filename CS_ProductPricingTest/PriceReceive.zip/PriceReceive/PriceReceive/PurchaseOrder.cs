﻿using System;
using System.Collections.Generic;

namespace PriceReceive
{
    public class PurchaseOrder
    {
        #region private members

        private double _purchaseOrderId { get; set; }
        private  string _productName { get; set; }
        private  float _executionPrice { get; set; }
        private  string _currency { get; set; }
        private  DateTime _executionTime { get; set; }
        private  double _notional { get; set; }
        private  string _counterparty { get; set; }

        #endregion

        #region .ctors

        public PurchaseOrder(string productName, float executionPrice, string currency,
            double notional, string counterparty)
        {
            _purchaseOrderId = GetPurchaseOrderId();
            _productName = productName;
            _executionPrice = executionPrice;
            _currency = currency;
            _executionTime = DateTime.Now;
            _notional = notional;
            _counterparty = counterparty;
        }

        #endregion

        #region public methods

        public int Save_Purchase_Order()
        {
            //this would normally save the trade to a database
            Console.WriteLine("\nPurchase order saved:\n" +
                " Purchase order id [{0}]\n" +
                " Product name [{1}]\n" +
                " Execution Price [{2}]\n" +
                " Currency [{3}]\n" +
                " Execution time [{4}]\n" +
                " Notional [{5}]\n" +
                " Counterparty [{6}]",
                _purchaseOrderId, _productName, _executionPrice, _currency,
                _executionTime.ToString("dd/MM/yyyy HH:mm:ss"),
                _notional, _counterparty);
            return MessageHandler.TRADE;
        }

        #endregion

        #region private methods

        private double GetPurchaseOrderId()
        {
            //ordinarily this will be a sequential unique trade id
            //which we would get from a cache or database
            return 1;
        }

        #endregion
    }
}
