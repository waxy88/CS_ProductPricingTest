﻿using System;
namespace PriceReceive
{
    public class Product
    {
        public string ProductName { get; set; }
        public float ProductOptionPrice { get; set; }
        public string DefaultCounterparty { get; set; }
    }
}
