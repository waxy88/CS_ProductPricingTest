﻿using System;
using System.Collections.Generic;

namespace PriceReceive
{
    public class Price
    {
        #region public members

        public string ProductName { get; set; }
        public float ProductPrice { get; set; }
        public string ProductCcy { get; set; }

        #endregion

        #region inteface methods

        public int CheckPrice(Dictionary<string, Product> productDict)
        {
            try
            {
                if (!productDict.ContainsKey(ProductName))
                {
                    Console.WriteLine("Error: Unknown product received.");
                    return MessageHandler.ERROR;
                }

                if (ProductPrice <= productDict[ProductName].ProductOptionPrice)
                {
                    if (ProductPrice < 0)
                    {
                        Console.WriteLine("Error: Cannot have negative prices");
                        return MessageHandler.ERROR;
                    }

                    //Terminate all price consumers, so no further trades are proposed
                    Console.WriteLine("\nOption triggered:\n " +
                        "Product: {0} Option: {1} Price: {2}",
                        ProductName, productDict[ProductName].ProductOptionPrice, ProductPrice);
                    MessageHandler.SendTerminateMessage();
                    return MessageHandler.TRADE;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
                return MessageHandler.ERROR;
            }
            return MessageHandler.CONTINUE;
        }

        #endregion
    }
}
