﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace PriceReceive
{
    public class MessageHandler
    {
        #region private members

        internal const int ERROR = -1;
        internal const int CONTINUE = 0;
        internal const int TRADE = 1;
        internal const int TERMINATE = 500;
        private static ConnectionFactory _factory = new ConnectionFactory();
        private Dictionary<string, Product> _prodDict = new Dictionary<string, Product>();
        private string _routingKey;

        #endregion

        #region .ctors

        public MessageHandler(string hostName, string routingKey, Dictionary<string, Product> prodDict)
        {
            _factory.HostName = hostName;
            _routingKey = routingKey;
            _prodDict = prodDict;
        }

        #endregion

        #region public methods

        public void Start()
        {
            using (var connection = _factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                
                channel.ExchangeDeclare(exchange: "price_exchange", type: ExchangeType.Direct);
                var queueName = channel.QueueDeclare().QueueName;
                channel.QueuePurge(queueName);

                channel.QueueBind(queue: queueName,
                    exchange: "price_exchange",
                    routingKey: _routingKey);

                channel.QueueBind(queue: queueName,
                    exchange: "price_exchange",
                    routingKey: "Terminate");

                Console.WriteLine("Waiting for messages.");

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    var routingKey = ea.RoutingKey;
                    Console.WriteLine("Received {0}", message);

                    var newPrice = new Price();
                    var status = CONTINUE;
                    status = ParseMessage(message, routingKey, ref newPrice);
                    if (status == ERROR || status == TERMINATE) connection.Close();

                    status = newPrice.CheckPrice(_prodDict);

                    if (status == TRADE)
                    {
                        var productName = newPrice.ProductName;
                        var newPurchaseOrder = new PurchaseOrder(
                            productName,
                            newPrice.ProductPrice,
                            newPrice.ProductCcy,
                            1, //spec only specified that the product should be purchased, not an amount
                            _prodDict[productName].DefaultCounterparty);
                        status = newPurchaseOrder.Save_Purchase_Order();
                    }

                    if (status == ERROR || status == TRADE)
                    {
                        SendTerminateMessage();
                        connection.Close();
                    }
                };
                channel.BasicConsume(queue: queueName, autoAck: true, consumer: consumer);

                Console.WriteLine(" Press [enter] to exit.");
                Console.ReadLine();
            }
        }

        public int ParseMessage(string message, string routingKey, ref Price newPrice)
        {
            try
            {
                string[] msgSplit = message.Split(',');

                //check for termination message
                if (routingKey == "Terminate" && msgSplit[0] == "TERMINATE") return TERMINATE;

                newPrice = new Price()
                {
                    ProductName = msgSplit[0],
                    ProductPrice = float.Parse(msgSplit[1]),
                    ProductCcy = msgSplit[2]
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
                return ERROR;
            }

            return CONTINUE;
        }

        #endregion

        #region internal methods

        internal static void SendTerminateMessage()
        {
            using (var connection = _factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: "price_exchange", type: ExchangeType.Direct);


                string message = "TERMINATE,,";
                var body = Encoding.UTF8.GetBytes(message);

                var properties = channel.CreateBasicProperties();
                properties.Persistent = true;

                channel.BasicPublish(exchange: "price_exchange",
                    routingKey: "Terminate",
                    basicProperties: properties,
                    body: body);
            }
        }

        #endregion
    }
}
