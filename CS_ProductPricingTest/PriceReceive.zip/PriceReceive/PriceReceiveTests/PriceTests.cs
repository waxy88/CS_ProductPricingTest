﻿using System.Collections.Generic;
using NUnit.Framework;
using PriceReceive;

namespace PriceReceiveTests
{
	public class PriceTests
	{
        private Dictionary<string, Product> _prodDict = new Dictionary<string, Product>();
        internal const int ERROR = -1;
        internal const int CONTINUE = 0;
        internal const int TRADE = 1;
        internal const int TERMINATE = 500;

        [SetUp]
        public void SetUp()
        {
            _prodDict.Add("AAA", new Product
            {
                ProductName = "AAA",
                ProductOptionPrice = 0.52F,
                DefaultCounterparty = "ABC"
            });
            
        }

        [Test]
        public void Returns_error_if_product_name_cannot_be_matched()
        {
            var testPrice = new Price()
            {
                ProductName = "BBB",
                ProductPrice = 1.23f,
                ProductCcy = "GBP"
            };

            var status = testPrice.CheckPrice(_prodDict);

            Assert.AreEqual(status, ERROR);
        }

        [Test]
        public void Returns_error_if_price_is_negative()
        {
            var testPrice = new Price()
            {
                ProductName = "AAA",
                ProductPrice = -1.23f,
                ProductCcy = "GBP"
            };

            var status = testPrice.CheckPrice(_prodDict);

            Assert.AreEqual(status, ERROR);
        }

        [Test]
        public void Returns_continue_if_price_above_option()
        {
            var testPrice = new Price()
            {
                ProductName = "AAA",
                ProductPrice = 1.23f,
                ProductCcy = "GBP"
            };

            var status = testPrice.CheckPrice(_prodDict);

            Assert.AreEqual(status, CONTINUE);
        }

        [Test]
        public void Returns_trade_if_price_equals_option()
        {
            var testPrice = new Price()
            {
                ProductName = "AAA",
                ProductPrice = 0.52f,
                ProductCcy = "GBP"
            };

            var status = testPrice.CheckPrice(_prodDict);

            Assert.AreEqual(status, TRADE);
        }

        [Test]
        public void Returns_trade_if_price_below_option()
        {
            var testPrice = new Price()
            {
                ProductName = "AAA",
                ProductPrice = 0.51f,
                ProductCcy = "GBP"
            };

            var status = testPrice.CheckPrice(_prodDict);

            Assert.AreEqual(status, TRADE);
        }

    }
}

