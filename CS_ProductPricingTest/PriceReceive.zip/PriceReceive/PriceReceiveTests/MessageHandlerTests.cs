﻿using System.Collections.Generic;
using NUnit.Framework;
using PriceReceive;

namespace PriceReceiveTests
{
    public class MessgeHandlerTests
    {
        private Dictionary<string, Product> _prodDict = new Dictionary<string, Product>();
        private string _routingKey;
        private Price _newPrice = new Price();
        internal const int ERROR = -1;
        internal const int CONTINUE = 0;
        internal const int TRADE = 1;
        internal const int TERMINATE = 500;

        [SetUp]
        public void SetUp()
        {
            _prodDict.Add("AAA", new Product
            {
                ProductName = "AAA",
                ProductOptionPrice = 0.52F,
                DefaultCounterparty = "ABC"
            });
            _routingKey = "1";
        }

        [Test]
        public void Populates_price_object_if_correct_format_message_received()
        {
            var message = "AAA,1.23,GBP";
            var testObj = new MessageHandler("localhost", _routingKey, _prodDict);

            var status = testObj.ParseMessage(message, _routingKey, ref _newPrice);

            Assert.AreEqual(_newPrice.ProductName, "AAA");
        }

        [Test]
        public void Returns_error_if_correct_format_message_is_not_received()
        {
            var message = "AAA";
            var testObj = new MessageHandler("localhost", _routingKey, _prodDict);

            var status = testObj.ParseMessage(message, _routingKey, ref _newPrice);

            Assert.AreEqual(status, ERROR);
        }

        [Test]
        public void Returns_error_if_non_numeric_price_is_received()
        {
            var message = "AAA,AAA,GBP";
            var testObj = new MessageHandler("localhost", _routingKey, _prodDict);

            var status = testObj.ParseMessage(message, _routingKey, ref _newPrice);

            Assert.AreEqual(status, ERROR);
        }

        [Test]
        public void Returns_error_empty_message_received()
        {
            var message = string.Empty;
            var testObj = new MessageHandler("localhost", _routingKey, _prodDict);

            var status = testObj.ParseMessage(message, _routingKey, ref _newPrice);

            Assert.AreEqual(status, ERROR);
        }

        [Test]
        public void Does_not_return_terminate_if__routingKey_is_not_terminate()
        {
            var message = "TERMINATE,,";
            var testObj = new MessageHandler("localhost", _routingKey, _prodDict);

            var status = testObj.ParseMessage(message, _routingKey, ref _newPrice);

            Assert.AreNotEqual(status, TERMINATE);
        }

        [Test]
        public void Does_return_terminate_if__routingKey_is_Terminate()
        {
            var message = "TERMINATE,,";
            _routingKey = "Terminate";
            var testObj = new MessageHandler("localhost", _routingKey, _prodDict);

            var status = testObj.ParseMessage(message, _routingKey, ref _newPrice);

            Assert.AreEqual(status, TERMINATE);
        }
    }
}
