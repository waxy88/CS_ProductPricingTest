﻿using System;
using RabbitMQ.Client;
using System.Timers;
using System.Text;
using System.Collections.Generic;

namespace PriceSend
{
    class Program
    {
        static Timer timer1 = new Timer();
        static List<string> productList = new List<string>() { "AAA", "BBB", "CCC", "DDD", "EEE" };

        static void Main()
        {
            var factory = new ConnectionFactory() { HostName = "localhost" };
            timer1.Interval = 1000; //2 second delay
            timer1.Elapsed += delegate { SendPrice(factory); };
            timer1.Start();
            Console.WriteLine("Press \'q\' to quit...");
            while (Console.Read() != 'q') ;
        }

        static private void SendPrice(ConnectionFactory factory)
        {
            Random rnd = new Random();
            using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: "price_exchange", type: ExchangeType.Direct);

                //generate random price
                var randNum1 = rnd.Next(1, 10);
                var randNum2 = rnd.Next(1, 100);
                var myPrice = Decimal.Divide(randNum1, randNum2);

                //randomly select a product to send
                var prodNum = rnd.Next(1, 5);

                //randomly generate which routing key to send to
                var routingKey = rnd.Next(1, 4);

                string message = productList[prodNum] +
                    "," + myPrice.ToString("0.00000") +
                    "," + "GBP";
                var body = Encoding.UTF8.GetBytes(message);

                var properties = channel.CreateBasicProperties();
                properties.Persistent = true;

                channel.BasicPublish(exchange: "price_exchange",
                    routingKey: routingKey.ToString(),
                    basicProperties: properties,
                    body: body);

                Console.WriteLine("Sent {0} to {1}", message, routingKey);
            }
        }
    }
}

